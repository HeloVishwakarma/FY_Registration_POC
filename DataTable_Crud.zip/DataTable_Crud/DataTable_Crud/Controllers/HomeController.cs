﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataTable_Crud.Models;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace DataTable_Crud.Controllers
{

    public class HomeController : Controller
    {
        public SqlConnection connect()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception)
            {

                throw;
            }

        }
        public ActionResult Index()
        {
           
            return View();
        }
        [HttpGet]
        public JsonResult GetCountry()
        {
            List<Country> cn = new List<Country>();
            DataSet ds = GetCountryData();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                cn.Add(new Country()
                {
                    CountryID = Convert.ToInt32(dr["CountryID"]),
                    CountryName = dr["CountryName"].ToString(),

                });
            }

            return Json(cn, JsonRequestBehavior.AllowGet);
        }
        public DataSet GetCountryData()
        {
            var cn = connect();
            List<Country> list = new List<Country>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
              
                cmd.Parameters.AddWithValue("@Action", "GetCountry");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;


            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet]
        public JsonResult GetState(int CountryID)
        {
            List<State> st = new List<State>();
            
            DataSet ds = GetStateData(CountryID);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                st.Add(new State()
                {
                    CountryID = Convert.ToInt32(dr["CountryID"]),
                    StateID = Convert.ToInt32(dr["StateID"]),
                    StateName = dr["StateName"].ToString(),
                });
            }
            
            return Json(st, JsonRequestBehavior.AllowGet);
        }
        public DataSet GetStateData(int CountryID)
        {
            var cn = connect();
            List<Country> list = new List<Country>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CountryID", CountryID);
                cmd.Parameters.AddWithValue("@Action", "GetStateByid");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;
               

            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult LoadData()
        {

            List<EmpModel> emp = GetData();
            return Json(emp, JsonRequestBehavior.AllowGet);

        }
        public List<EmpModel> GetData()
        {
            var cn = connect();
            List<EmpModel> list = new List<EmpModel>();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "SelectAll");
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    EmpModel emp = new EmpModel();

                    emp.id = Convert.ToInt32(dr["EmployeeID"].ToString());
                    emp.Name = dr["Name"].ToString();
                    emp.Age = Convert.ToInt32(dr["Age"].ToString());
                    emp.State = dr["StateName"].ToString();
                    emp.Country = dr["CountryName"].ToString();
                    //emp.Action = "<a class='btn btn-primary fa fa-edit'   href='index" + ( new { Id = emp.id }) + "'data-toggle='modal' data-target='#myModal'>Update</a>&nbsp<a class='btn btn-danger fa fa-trash' href='" + ("Index", "Home", new { Id = emp.id }) + "'>Delete</a>";
                    list.Add(emp);

                }
                return list;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult GetbyID(int empID)
        {
            List<EmpModel> emp = new List<EmpModel>();
            DataSet ds = GetEmpDatabyID(empID);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                emp.Add(new EmpModel()
                {
                    id = Convert.ToInt32(dr["EmployeeID"]),
                    Name = dr["Name"].ToString(),
                    Age = Convert.ToInt32(dr["Age"]),
                    CountryID = Convert.ToInt32(dr["CountryID"]),
                    StateID = Convert.ToInt32(dr["StateID"]),
                   
                });
            }

            return Json(emp, JsonRequestBehavior.AllowGet);

        }
        public DataSet GetEmpDatabyID(int empID)
        {
            var cn = connect();
            List<EmpModel> list = new List<EmpModel>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", empID);
                cmd.Parameters.AddWithValue("@Action", "GetEmpDatabyID");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;


            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult InsertUpdateEmployee(EmpModel empObj)
        {
            int a = InsertUpdate(empObj);
            return Json(a, JsonRequestBehavior.AllowGet);
        }
        public int InsertUpdate(EmpModel emp)
        {
            var con = connect();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", emp.id);
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@Age", emp.Age);
                cmd.Parameters.AddWithValue("@StateID", emp.StateID);
                cmd.Parameters.AddWithValue("@CountryID", emp.CountryID);
                cmd.Parameters.AddWithValue("@Action", "InsertUpdate");
                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult Delete(int ID)
        {
             return Json(DeleteEmployee(ID), JsonRequestBehavior.AllowGet);
        }

        public int DeleteEmployee(int ID)
        {
            var con = connect();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", ID);
                cmd.Parameters.AddWithValue("@Action", "Delete");
                int i = cmd.ExecuteNonQuery();
                return i;

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}