﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataTable_Crud.Models
{
    public class EmpModel
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public int StateID { get; set; }
        public int CountryID { get; set; }

    }
}