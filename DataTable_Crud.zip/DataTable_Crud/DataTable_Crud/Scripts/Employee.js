﻿var Employee = function () {
    var init = function () {
      loaddata();
        GetCountry();
    }
    var GetCountry = function () {
        $.ajax({
            type: "GET",
            url: "/Home/GetCountry",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].CountryID + '">' + data[i].CountryName + '</option>'; }
                $("#ddlCountry").html(string);
            },
            error: function (response) {
                alert(response.d);
            }
        })
    }
    $("#ddlCountry").change(function () {
        $.ajax({
            type: "GET",
            url: "/Home/GetState?CountryID=" + $("#ddlCountry").val(),
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].StateID + '">' + data[i].StateName + '</option>'; }
                $("#ddlState").html(string);
            },
            error: function (response) {
                alert(response.d);
            }
        })
    })
    var loaddata = function () {
        $.ajax({
            type: "GET",
            url: "/Home/LoadData",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccess,
            failure: function (response) {
                alert(response.d);
            },
            error: function (response) {
                alert(response.d);
            }
        });
    };
    var OnSuccess = function (response) {
        $("#tblCustomers").DataTable(
            {

                bLengthChange: true,
                lengthMenu: [[5, 10, -1], [5, 10, "All"]],
                bFilter: true,
                bSort: true,
                bPaginate: true,
                data: response,
                destroy: true,
                columns: [{ 'data': 'id' },
                { 'data': 'Name' },
                { 'data': 'Age' },
                { 'data': 'State' },
                { 'data': 'Country' },
                { 'data': 'id', "width": "150px", "render": function (id) { return '<button type="button" data-toggle="modal" data-target="#myModal"  class="btn btn-primary"onclick="return GetbyID(' + id + ')"><i class="fa fa-edit">&nbspUpdate</i></button>&nbsp<button type="button"  class="btn btn-danger"onclick="Delete(' + id + ')"><i class="fa fa-trash">&nbspDelete</i></button>' } }]
            });
    }
 
    $("#btnAdd").click(function () {
        if ($("#Name").val() == '') {
            alert("Please Enter Employee Name")
            $(".txt-mytxtarea").focus();
            return false;
        }
        else if ($("#Age").val() == '') {
            alert("Please Enter Age")
            $("#ddlCourse1").focus();
            return false;
        }
        else if ($("#ddlCountry").val() == '-1') {
            alert("Please select Country")
            $("#ddlCourse1").focus();
            return false;
        }
        else if ($("#ddlState").val() == '-1') {
            alert("Please select State")
            $("#ddlCourse1").focus();
            return false;
        }

        var empObj = {
            id: $('#EmployeeID').val(),
            Name: $('#Name').val(),
            Age: $('#Age').val(),
            StateID: $('#ddlState').val(),
            CountryID: $('#ddlCountry').val()
        };
        $.ajax({
            url: "/Home/InsertUpdateEmployee",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(empObj),
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                alert("Employee Added")
                clearTextBox();
                loaddata();
            },
            error: function (errormessage) {
                alert("Somthing went wrong");
            }

        });
    })
    $("#btnModel").click(function () {
        clearTextBox();
    })
    function clearTextBox() {
        $('#EmployeeID').val("");
        $('#Name').val("");
        $('#Age').val("");
        $('#ddlState').val(-1);
        $('#ddlCountry').val(-1);
        $('#btnAdd').text("Save");

    }
    var loadEmployeeData = function (result) {
        //console.log(result)
        $('#EmployeeID').val(result[0].id);
        $('#Name').val(result[0].Name);
        $('#Age').val(result[0].Age);
        $('#ddlCountry').val(result[0].CountryID);
        
        var stateid = result[0].StateID
        LoadSateData(stateid);
        $('#ddlState').val(result[0].StateID);
        $('#btnAdd').text("Update");
    }
    var LoadSateData = function (stateid) {
        $.ajax({
            type: "GET",
            url: "/Home/GetState?CountryID=" + $("#ddlCountry").val(),
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].StateID + '">' + data[i].StateName + '</option>'; }
                $("#ddlState").html(string);
                $("#ddlState").val(stateid);
            },
            error: function (response) {
                alert(response.d);
            }
        })
    }
    return {
        Init: init,
        LoadEmployeeData: loadEmployeeData,
      //  Loaddata: loaddata
    }
}();

function editFormatter(data) {
    return '<button type="button" data-toggle="modal" data-target="#myModal"  class="btn btn-primary"onclick="return GetbyID(' + id + ')"><i class="fa fa-edit">&nbspUpdate</i></button>&nbsp<button type="button"  class="btn btn-danger"onclick="Delete(' + id + ')"><i class="fa fa-trash">&nbspDelete</i></button>'
}