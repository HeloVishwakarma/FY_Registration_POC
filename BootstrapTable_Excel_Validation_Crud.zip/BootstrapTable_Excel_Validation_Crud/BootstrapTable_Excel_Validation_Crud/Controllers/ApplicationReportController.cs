﻿using BootstrapTable_Excel_Validation_Crud.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BootstrapTable_Excel_Validation_Crud.Controllers
{
    public class ApplicationReportController : Controller
    {
        DbConnection cn = new DbConnection();
       

        // GET: ApplicationReport
        public ActionResult Index(int studentid)
        {
            //if(Session["studentid"] == null)
            //{
            //    return Redirect("/StudentAdmission/StudentAdmission");
            //}
            Session["studentid"] = studentid;
            return View();
        }
        public ActionResult GetApplicationReport()
        {
            if (Session["studentid"] == null)
            {
                return Redirect("/StudentAdmission/StudentAdmission");
            }
            int studentid = Convert.ToInt32(Convert.ToString(Session["studentid"]));
            var  data = FillDatasetIntoApplicationreportmodel(studentid);
            return Json(JsonConvert.SerializeObject(data));
        }
        private VMApplicationReport FillDatasetIntoApplicationreportmodel(int studentid)
        {
            var con = cn.connect();
            try
            {
                VMApplicationReport vmApplicationReport = new VMApplicationReport();
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentID", studentid);
                cmd.Parameters.AddWithValue("@Action", "GetApplicationreportdata");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                vmApplicationReport.StudentData = (from DataRow dr in ds.Tables[0].Rows
                        select new StudentModel
                        {
                            StudentID = int.Parse(dr[0].ToString()),
                            FirstName = dr[1].ToString(),
                            MiddleName = dr[2].ToString(),
                            LastName = dr[3].ToString(),
                            Email = dr[4].ToString(),
                            DateOFBirth = Convert.ToDateTime(dr[5].ToString()),
                            Address = dr[6].ToString(),
                            MobileNo = dr[7].ToString(),
                            Country = dr[8].ToString(),
                            State = dr[9].ToString(),
                            City = dr[10].ToString(),
                            AdharCardNo = dr[11].ToString(),
                            PanCardNo = dr[12].ToString(),
                            ImagePath = dr[13].ToString(),

                        }).ToList();

                return vmApplicationReport;
            }
            catch
            {
                throw;
            }
            
        }
    }
}