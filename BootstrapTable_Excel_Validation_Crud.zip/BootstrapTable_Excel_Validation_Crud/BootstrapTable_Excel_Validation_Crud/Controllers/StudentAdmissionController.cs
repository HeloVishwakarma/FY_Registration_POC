﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BootstrapTable_Excel_Validation_Crud.Models;

namespace BootstrapTable_Excel_Validation_Crud.Controllers
{
    public class StudentAdmissionController : Controller
    {
        DbConnection cn = new DbConnection();
        // GET: StudentAdmission
        public ActionResult StudentAdmission()
        {
            if(Session["RegistrationID"] != null)
            {
                return View();
            }
            return Redirect("/Login/Login");
        }
        [HttpGet]
        public JsonResult GetCountry()
        {
            List<Country> cn = new List<Country>();
            DataSet ds = GetCountryData();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                cn.Add(new Country()
                {
                    CountryID = Convert.ToInt32(dr["CountryID"]),
                    CountryName = dr["CountryName"].ToString(),

                });
            }

            return Json(cn, JsonRequestBehavior.AllowGet);
        }
        public DataSet GetCountryData()
        {
            var con = cn.connect();
            List<Country> list = new List<Country>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Action", "GetCountry");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet]
        public JsonResult GetState(int CountryID)
        {
            List<State> st = new List<State>();
            DataSet ds = GetStateData(CountryID);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                st.Add(new State()
                {
                    CountryID = Convert.ToInt32(dr["CountryID"]),
                    StateID = Convert.ToInt32(dr["StateID"]),
                    StateName = dr["StateName"].ToString(),
                });
            }

            return Json(st, JsonRequestBehavior.AllowGet);
        }
        public DataSet GetStateData(int CountryID)
        {
            var con = cn.connect();
            List<Country> list = new List<Country>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CountryID", CountryID);
                cmd.Parameters.AddWithValue("@Action", "GetStateByid");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;


            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet]
        public JsonResult GetCity(int StateID)
        {
            List<City> st = new List<City>();
            DataSet ds = GetCityData(StateID);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                st.Add(new City()
                {
                    
                    StateID = Convert.ToInt32(dr["StateID"]),
                    CityName = dr["CityName"].ToString(),
                    CityID = Convert.ToInt32(dr["CityID"])
                });
            }

            return Json(st, JsonRequestBehavior.AllowGet);
        }
        public DataSet GetCityData(int StateID)
        {
            var con = cn.connect();
            List<City> list = new List<City>();
            try
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StateID", StateID);
                cmd.Parameters.AddWithValue("@Action", "GetCityByid");
                SqlDataAdapter objDataAdapter = new SqlDataAdapter();
                objDataAdapter = new SqlDataAdapter(cmd);
                objDataAdapter.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                throw;
            }
        }
        [HttpPost]
        public JsonResult SaveAdmissionData(StudentModel obj)
        {
            //int User_Id = Convert.ToInt32(Session["User_ID"]);
            //var courses = Request.Form["course"].ToString().Split(',');
            var files = Request.Files;
            string img = Request.Form["ImagesName"].ToString();
            var images = new List<string>();
            foreach (var item in files)
            {
                images.Add(files[item.ToString()].FileName);
            }
            foreach (var item in files)
            {
                string iamge = Path.GetFileName(files[item.ToString()].FileName);
                //Debug.WriteLine(iamge);
                var path = Server.MapPath("/Uploads/Images/") + iamge;
                files[item.ToString()].SaveAs(path);
            }
            int i = SaveData(obj,img);
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        public int SaveData(StudentModel obj, string img)
        {
            var con = cn.connect();
            try
            {
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", obj.RegistrationID);
                cmd.Parameters.AddWithValue("@FirstName",obj.FirstName);
                cmd.Parameters.AddWithValue("@MiddleName",obj.MiddleName);
                cmd.Parameters.AddWithValue("@LastName",obj.LastName);
                cmd.Parameters.AddWithValue("@Email",obj.Email);
                cmd.Parameters.AddWithValue("@DateOfBirth", obj.DateOFBirth);
                cmd.Parameters.AddWithValue("@MobileNo",obj.MobileNo);
                cmd.Parameters.AddWithValue("@Address",obj.Address);
                cmd.Parameters.AddWithValue("@CountryID",obj.CountryID);
                cmd.Parameters.AddWithValue("@StateID",obj.StateID);
                cmd.Parameters.AddWithValue("@CityID",obj.CityID);
                cmd.Parameters.AddWithValue("@AdharCardNumber",obj.AdharCardNo);
                cmd.Parameters.AddWithValue("@PanCardNo",obj.PanCardNo);
                cmd.Parameters.AddWithValue("@ImagePath",img);
                cmd.Parameters.AddWithValue("@IsActive",1);
                cmd.Parameters.AddWithValue("@Action", "InsertUpdate");
                int flag = cmd.ExecuteNonQuery();
                return flag;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult GetStudentData()
        {

            var ab = FillDatasetIntoModel();
            return Json(ab, JsonRequestBehavior.AllowGet);
            
        }
        private List<StudentModel> FillDatasetIntoModel()
        {
            var con = cn.connect();
            try
            {
                SqlCommand cmd = new SqlCommand("StudentSp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IsActive", 1);
                cmd.Parameters.AddWithValue("@Action", "GetStudentData");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                List<StudentModel> Data = new List<StudentModel>();
                Data = (from DataRow dr in ds.Tables[0].Rows
                        select new StudentModel
                        {
                            StudentID = int.Parse(dr[0].ToString()),
                            FirstName = dr[1].ToString(),
                            MiddleName = dr[2].ToString(),
                            LastName = dr[3].ToString(),
                            Email = dr[4].ToString(),
                            DateOFBirth = Convert.ToDateTime(dr[5].ToString()),
                            Address = dr[6].ToString(),
                            MobileNo = dr[7].ToString(),
                            Country = dr[8].ToString(),
                            State = dr[9].ToString(),
                            City = dr[10].ToString(),
                            AdharCardNo = dr[11].ToString(),
                            PanCardNo = dr[12].ToString(),
                            ImagePath = dr[13].ToString(),

                        }).ToList();
                return Data;
            }
            catch
            {
                throw;
            }
        }
      
    }
}