﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BootstrapTable_Excel_Validation_Crud.Models;

namespace BootstrapTable_Excel_Validation_Crud.Controllers
{
    public class RegistrationController : Controller
    {
        DbConnection cn = new DbConnection();
        // GET: Registration
        public ActionResult Registration()
        {
            return View();
        }
        int count;
        [HttpPost]
        public JsonResult CheckUserName(RegistrationLoginModel obj)
        {
            int i = CheckUser(obj);
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        public int CheckUser(RegistrationLoginModel obj)
        {
            var con =cn.connect();
            try
            {
                SqlCommand cmd = new SqlCommand("RegistrtionLogin", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@Action", "CheckUserName");
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    count = (int)dr["UserName"];

                }
            }
            catch (Exception)
            {

                throw;
            }
            return count;
        }
        [HttpPost]
        public JsonResult Registration(RegistrationLoginModel obj)
        {
            int i = UserRegistration(obj);
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        public int UserRegistration(RegistrationLoginModel obj)
        {
            var con = cn.connect();
            try
            {
                SqlCommand cmd = new SqlCommand("RegistrtionLogin", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@Email", obj.Email);
                cmd.Parameters.AddWithValue("@Password", obj.Password);
                cmd.Parameters.AddWithValue("@IsAdmin", 0);
                cmd.Parameters.AddWithValue("@Action", "Registration");
                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            Session.Clear();
            return Redirect("/Login/Login");
        }
    }
}