﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BootstrapTable_Excel_Validation_Crud.Models;
using System.Data;
using System.Data.SqlClient;

namespace BootstrapTable_Excel_Validation_Crud.Controllers
{
    public class LoginController : Controller
    {
        DbConnection cn = new DbConnection();
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        string value;
        [HttpPost]
        public JsonResult Login(RegistrationLoginModel obj)
        {
            SqlDataReader dr = LoginUser(obj);
            if (dr.Read())
            {
                if(dr["RegistrationID"] != null)
                {
                    Session["RegistrationID"] = dr["RegistrationID"];
                    Session["UserName"] = dr["UserName"];
                    Session["Email"] = dr["Email"];

                    if (dr["IsAdmin"].ToString() == "True")
                    {
                        value = "1";
                    }
                    if (dr["IsAdmin"].ToString() == "False")
                    {
                        value = "0";
                    }
                    
                }
                else
                {
                    return Json(-99, JsonRequestBehavior.AllowGet);
                }
               
            }
            else
            {
                return Json(-99, JsonRequestBehavior.AllowGet);
            }
            return Json(value, JsonRequestBehavior.AllowGet);
        }
        public SqlDataReader LoginUser(RegistrationLoginModel obj)
        {
            var con = cn.connect();

            try
            {
                SqlCommand cmd = new SqlCommand("RegistrtionLogin", con);
                cmd.CommandType = CommandType.StoredProcedure;
              

                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@Password", obj.Password);

                cmd.Parameters.AddWithValue("@Action", "Login");
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlDataReader dr = cmd.ExecuteReader();
                return dr;
            }
            catch (Exception)
            {

                throw;
            }
        }
       
    }
}