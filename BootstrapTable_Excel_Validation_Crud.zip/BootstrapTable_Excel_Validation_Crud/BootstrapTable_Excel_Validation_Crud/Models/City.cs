﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BootstrapTable_Excel_Validation_Crud.Models
{
    public class City
    {
        public int StateID { get; set; }
        public int CityID { get; set; }
        public string CityName { get; set; }
    }
}