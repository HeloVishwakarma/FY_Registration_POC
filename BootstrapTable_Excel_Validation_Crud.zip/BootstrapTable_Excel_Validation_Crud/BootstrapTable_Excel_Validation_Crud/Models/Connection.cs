﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace BootstrapTable_Excel_Validation_Crud.Models
{
    public class Connection
    {
        public ConnectionState State { get; internal set; }

        public SqlConnection connect()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}