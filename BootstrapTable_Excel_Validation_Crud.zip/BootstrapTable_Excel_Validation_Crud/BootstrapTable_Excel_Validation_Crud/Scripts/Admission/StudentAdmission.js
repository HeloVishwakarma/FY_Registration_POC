﻿var StudentAdmission = function () {
    var init = function () {
        GetCountry();
        loaddata();
    };

    var GetCountry = function () {
        $.ajax({
            type: "GET",
            url: "/StudentAdmission/GetCountry",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].CountryID + '">' + data[i].CountryName + '</option>'; }
                $("#ddlCountry").html(string);
            },
            error: function (response) {
                alert(response.d);
            }
        })
    }
    $("#ddlCountry").change(function () {
        $.ajax({
            type: "GET",
            url: "/StudentAdmission/GetState?CountryID=" + $("#ddlCountry").val(),
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].StateID + '">' + data[i].StateName + '</option>'; }
                $("#ddlState").html(string);

            },
            error: function (response) {
                alert(response.d);
            }
        })
    })
    $("#ddlState").change(function () {
        $.ajax({
            type: "GET",
            url: "/StudentAdmission/GetCity?StateID=" + $("#ddlState").val(),
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var string = '<option value="-1">--- Please Select ---</option>';
                for (var i = 0; i < data.length; i++) { string += '<option value="' + data[i].CityID + '">' + data[i].CityName + '</option>'; }
                $("#ddlCity").html(string);

            },
            error: function (response) {
                alert(response.d);
            }
        })
    })
    $("#btnSaveAdmission").click(function () {
        if ($("#txtFName").val() == '') {
            alert("Please Enter First Name")
            $("#txtFName").focus();
            return false;
        }
        else if ($("#txtMName").val() == '') {
            alert("Please Enter Middle Name")
            $("#txtMName").focus();
            return false;
        }
        else if ($("#txtLName").val() == '') {
            alert("Please Enter Last Name")
            $("#txtLName").focus();
            return false;
        }
        else if ($("#txtDob").val() == '') {
            alert("Please Select Date Of Birth ")
            $("#txtDob").focus();
            return false;
        }
        var mobile = $("#txtMobileNo").val();
        if (mobile == "") {
            alert("Please Enter Mobile No")
            $("#txtDob").focus();
            return false;
        }
        else {
            if (mobile.length != 10) {
                alert("Please Enter 10 Digit Mobile Number");
                $('#txtMobileNo').focus();
                return false;
            }
            else {
            }
        }
        var emailVal = $("#txtEmail").val();
        if (emailVal == "") {
            alert("Please Enter Email");
            $('#txtEmail').focus();
            return false;
        }
        else {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(emailVal)) {
            }
            else {
                alert("Please Enter email in Correct Format!");
                $('#txtEmail').focus();
                return false;
            }
        }
        if ($("#txtAddress").val() == '') {
            alert("Please Enter address")
            $("#txtAddress").focus();
            return false;
        }
        else if ($("#ddlCountry").val() == -1) {
            alert("Please Select Country ")
            $("#ddlCountry").focus();
            return false;
        }
        else if ($("#ddlState").val() == -1) {
            alert("Please Select State")
            $("#ddlState").focus();
            return false;
        }
        else if ($("#ddlCity").val() == -1) {
            alert("Please Select City ")
            $("#ddlCity").focus();
            return false;
        }
        var adhar = $("#txtAdharNo").val();
        if (adhar == "") {
            alert("Please Enter adhar No ")
            $("#txtAdharNo").focus();
            return false;
        }
        else {
            if (adhar.length == 12) {
            }
            else {
                alert("Please Enter Correct Adhar No!");
                $('#txtAdharNo').focus();
                return false;
            }
        }

        var panCard = $("#txtPanNo").val();
        if (panCard == "") {
            alert("Please Enter Correct Pan No!");
            $('#txtPanNo').focus();
            return false;
        }
        else {
            var filter = /[A-Z]{5}\d{4}[A-Z]{1}/;
            if (filter.test(panCard)) {
            }
            else {
                alert("Please Enter valid pan no.");
                $('#txtPanNo').focus();
                return false;
            }
        }
        if ($("#ProfilePhoto").val() == '') {
            alert("Please select Profile Photo")
            $("#ProfilePhoto").focus();
            return false;
        }
        var formData = new FormData();
        var files = $("#ProfilePhoto").get(0).files;
        formData.append("ImagesName", files[0].name);

        formData.append("file", files[0]);
        formData.append("RegistrationID", $('#txthiddenUserID').val());
        formData.append("FirstName", $('#txtFName').val());
        formData.append("MiddleName", $('#txtMName').val());
        formData.append("LastName", $('#txtLName').val());
        formData.append("DateOFBirth", $('#txtDob').val());
        formData.append("MobileNo", $('#txtMobileNo').val());
        formData.append("Email", $('#txtEmail').val());
        formData.append("Address", $('#txtAddress').val());
        formData.append("CountryID", $('#ddlCountry').val());
        formData.append("StateID", $('#ddlState').val());
        formData.append("CityID", $('#ddlCity').val());
        formData.append("AdharCardNo", $('#txtAdharNo').val());
        formData.append("PanCardNo", $('#txtPanNo').val());
        var ans = confirm("Are you sure to submit Your Data After Submit Data will be Not Edited ?");
        if (ans) {
            $.ajax({
                type: 'POST',
                url: "/StudentAdmission/SaveAdmissionData",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (response) {

                    alert("successfully Image Insert");

                },
                error: function (ee) {
                    alert("Somethong Went Wromg");
                },
                complete: function (data) {
                    loadImages();
                }
            })
        }
       
    })
    var loaddata = function () {
        $.ajax({
            type: "GET",
            url: "/StudentAdmission/GetStudentData",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                console.log(response);
                LoadTabledata(response);
            },
            error: function (response) {
                alert(response.d);
            }
        });
    };
    var LoadTabledata = function (response) {
        $("#tblStudent").DataTable(
            {
                bLengthChange: true,
                lengthMenu: [[5, 10, -1], [5, 10, "All"]],
                bFilter: true,
                bSort: true,
                bPaginate: true,
                data: response,
                destroy: true,
                columns: [
                    {
                        'data': 'StudentID', "width": "150px", "render": function (StudentID) {
                            return '<button type="button" data-toggle="modal" data-target="#myModal"  class="btn btn-primary"onclick="return GetDatabyID(' + StudentID + ')"><i class="fa fa-edit">&nbspGetReport</i></button>'
                        }

                    },
                    { 'data': 'StudentID' },
                    { 'data': 'FirstName' },
                    { 'data': 'MiddleName' },
                    { 'data': 'LastName' },
                    { 'data': 'Email' },
                    { 'data': 'MobileNo' },
                    {
                        'data': 'ImagePath', "width": "150px", "render": function (ImagePath) {
                            return '<img src="/Uploads/Images/' + ImagePath + '" class="avatar" width="100" height="100"/>'
                        }

                    }]
            });
    }
    $("#btnLogOut").click(function () {
        alert("are You sure for logout Your session")
        $.ajax({
            url: "/Registration/Logout",
            method: "POST",
            success: function (res) {
                alert("Logout Success");
                window.location = "/Login/Login";
            },
            error: function (err) {

            }

        })
    })
    return {
        Init: init
    };
}();