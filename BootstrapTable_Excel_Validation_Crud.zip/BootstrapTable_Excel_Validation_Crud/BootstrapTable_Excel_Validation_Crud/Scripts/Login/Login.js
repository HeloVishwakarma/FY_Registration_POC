﻿var Login = function () {
    var init = function () {

    };
    $("#btnLogin").click(function () {
        if ($("#txtUserName").val() == '') {
            alert("Please Enter UserName")
            $("#txtUserName").focus();
            return false;
        }
        if ($("#txtPassword").val() == '') {
            alert("Please Enter Password")
            $("#txtPassword").focus();
            return false;
        }
        var formdata = {
            UserName: $("#txtUserName").val(),
            Password: $("#txtPassword").val()
        }
   
            $.ajax({
                url: "/Login/Login",
                method: "POST",
                data: JSON.stringify(formdata),
                contentType: 'application/json; charset=utf-8',
                success: function (res) {
                    if (res == 0) {
                        window.location = "/StudentAdmission/StudentAdmission";
                    }
                    if (res == 1) {
                        window.location = "/Admin/Admin";
                    }
                    if (res == -99) {
                        alert("Invalide UserName Password");
                     
                    }
                },
                error: function (err) {
                    alert("Something went wrong");
                }

            })
    })
    return {
        Init: init
    };
}();