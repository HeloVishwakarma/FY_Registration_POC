﻿var Registration = function () {
    var init = function () {
        
    };
    $("#btnRegister").click(function () {
        if ($("#txtUserName").val() == '') {
            alert("Please Enter User Name")
            $("#txtUserName").focus();
            return false;
        }
        var emailVal = $("#txtEmail").val();
        if (emailVal == "") {
            alert("Please Enter Email")
            $("#txtEmail").focus();
            return false;
        }
        else {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(emailVal)) {
            }
            else {
                alert("Please Enter email in Correct Format!");
                $('#txtEmail').focus();
                return false;
            }
        }
        if ($("#txtPassword").val().length < 6) {
            alert('Password Must Be Minimum 6 Characters Long');
            $('#txtPassword').focus();
            return false;
        }
        else if (!passwordMatch($.trim($('#txtPassword').val()), $.trim($('#txtConfirmPassword').val()))) {
            alert('Password Not Matched');
            $('#txtConfirmPassword').focus();
            return false;
        }
        var formdata = {
            UserName: $("#txtUserName").val(),
            Email: $("#txtEmail").val(),
            Password: $("#txtPassword").val()
        }
        $.ajax({
            url: "/Registration/CheckUserName",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(formdata),
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                if (result == '0') {
                    Register();
                }
                else if (result == '1') {
                    alert("User Already Exits");
                }
            },
            error: function (errormessage) {
                alert("Somthing went wrong");
            }
        })

    })
    function Register() {

        var formdata = {
            UserName: $("#txtUserName").val(),
            Email: $("#txtEmail").val(),
            Password: $("#txtPassword").val()
        }
        console.log(formdata);
        $.ajax({
            url: "/Registration/Registration",
            method: "POST",
            data: JSON.stringify(formdata),
            contentType: 'application/json; charset=utf-8',
            success: function (res) {
                alert("Registration Done Plz Login Now");
                window.location = "/Login/Login";
            },
            error: function (err) {
                alert("Something went wrong");
            }

        })
    }
  
    var passwordMatch = function (password, cpassword) {
        return password == cpassword ? true : false;
    }
    return {
        Init: init
    };
}();