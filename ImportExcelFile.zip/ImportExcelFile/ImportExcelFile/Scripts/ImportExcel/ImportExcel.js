﻿var ImportExcel = function () {
    var flag = 0; var buttonType = "", jsonDt = "", btnImportFlag = 0;
    var Init = function () {
        $('#dvExcelColumnsCheck_imp').hide();
        $('#dvExcelDataList_imp').hide();
    }
    
    $('#UploadedFile_imp').click(function () {

        $("#UploadedFile_imp").val("");
        $('#UploadedFile_imp').val('').clone(true);
        $('#dvExcelColumnsCheck_imp').hide();
        $('#dvExcelDataList_imp').hide();
      

    });
    $('#btnViewData').click(function () {
        $("#btnImportData").removeAttr("disabled", "disabled");

        //$('#divLoading_imp').show();

        var regex = /\.(xlsx|xls)$/i;
        var fileUpload = $("#UploadedFile_imp")[0];
        /*Checks whether the file is a valid excel file*/
        if (regex.test($("#UploadedFile_imp").val().toLowerCase())) {
            Datacheck_imp();
        }
        else {
            alert('Please Upload a Valid Excel File', 'Warning');
            ClearMessage_imp();
            // $('#divLoading_imp').hide();
            return false;
        }

    });
    $('#btnImportData').click(function () {
        
        //$('#divLoading_imp').show();
        buttonType = "Upload";
        $('#tbodyExcelColumns_imp').empty();

        var regex = /\.(xlsx|xls)$/i;
        // olg reg ex   /^([a-zA-Z0-9\s_\\.\-:])+(.xlsx|.xls)$/;
        var fileUpload = $("#UploadedFile_imp")[0];
        /*Checks whether the file is a valid excel file*/
        if (regex.test($("#UploadedFile_imp").val().toLowerCase())) {
            //Datacheck_imp();
            $('#exceltable_imp').empty();
            $('#btnImportData').text(" ..Processing");
            $('#btnImportData').attr("disabled", "disabled");
            $('#UploadedFile_imp').attr("disabled", "disabled");
            $('#btnViewData').attr("disabled", "disabled");
            ImportToExcel_imp();
        }
        else {
            //toastr.warning('Please Upload a Valid Excel File', 'Warning');
            alert('Please Upload a Valid Excel File', 'Warning');
            ClearMessage_imp();
            return false;
        }
    });
    var ImportToExcel_imp = function () {

        var regex = /\.(xlsx|xls)$/i;
        // olg reg ex   /^([a-zA-Z0-9\s_\\.\-:])+(.xlsx|.xls)$/;
        var fileUpload = $("#UploadedFile_imp")[0];
        /*Checks whether the file is a valid excel file*/
        if (regex.test($("#UploadedFile_imp").val().toLowerCase())) {
            var xlsxflag = false; /*Flag for checking whether excel is .xls format or .xlsx format*/
            if ($("#UploadedFile_imp").val().toLowerCase().indexOf(".xlsx") > 0) {
                xlsxflag = true;
            }
            /*Checks whether the browser supports HTML5*/
            if (typeof (FileReader) != "undefined") {
                var reader = new FileReader();

                if (reader.readAsBinaryString) {
                    reader.onload = function (e) {
                        var data = e.target.result;
                        /*Converts the excel data in to object*/
                        if (xlsxflag) {
                            var workbook = XLSX.read(data, { type: 'binary' });
                        }
                        else {
                            var workbook = XLS.read(data, { type: 'binary' });
                        }
                        /*Gets all the sheetnames of excel in to a variable*/
                        var sheet_name_list = workbook.SheetNames;

                        var WkSheetName = sheet_name_list[0];

                        var cnt = 0; /*This is used for restricting the script to consider only first sheet of excel*/

                        if (xlsxflag) {
                            var exceljson = XLSX.utils.sheet_to_json(workbook.Sheets[WkSheetName]);
                        }
                        else {
                            var exceljson = XLS.utils.sheet_to_row_object_array(workbook.Sheets[WkSheetName], { defval: null });
                        }
                        if (exceljson.length > 0 && cnt == 0) {

                            BindTable_imp(exceljson, '#exceltable_imp');
                            cnt++;
                        }

                    }
                    if (xlsxflag) {/*If excel file is .xlsx extension than creates a Array Buffer from excel*/
                        reader.readAsArrayBuffer($("#UploadedFile_imp")[0].files[0]);
                    }
                    else {
                        reader.readAsBinaryString($("#UploadedFile_imp")[0].files[0]);
                    }
                }
            }
            else {
                toastr.warning('Sorry! Your Browser does not Support HTML5', 'Warning!');
                return false;
            }
        }
        else {
            toastr.warning('Please Upload a Valid Excel File', 'Warning!');
            return false;
        }
    }
    var BindTable_imp = function (jsondata, tableid) {/*Function used to convert the JSON array to Html Table*/

        var columns = BindTableHeader_imp(jsondata, tableid); /*Gets all the column headings of Excel*/
        var j = 1;
        for (var i = 0; i < jsondata.length; i++) {
            var row$ = "<tbody id='tbodyexceltable_imp'><tr class='bg-light-blue'>";

            row$ += '<td> ' + (j++) + ' ';
            row$ += ' </td>';

            row$ += '<td> ' + (jsondata[i]["MobileNo"] == null ? "" : jsondata[i]["MobileNo"]) + ' ';
            row$ += '<input type="hidden" id="hdnMobileNo" name="hdnMobileNo" value = "' + (jsondata[i]["MobileNo"] == null ? "" : jsondata[i]["MobileNo"]) + '"/> </td>';

            row$ += '<td> ' + (jsondata[i]["EmailId"] == null ? "" : jsondata[i]["EmailId"]) + ' ';
            row$ += '<input type="hidden" id="hdnEmailId" name="hdnEmailId" value = "' + (jsondata[i]["EmailId"] == null ? "" : jsondata[i]["EmailId"]) + '"/> </td> ';

            row$ += '<td> ' + (jsondata[i]["Username"] == null ? "" : jsondata[i]["Username"]) + ' ';
            row$ += '<input type="hidden" id="hdnUsername" name="hdnUsername" value = "' + (jsondata[i]["Username"] == null ? "" : jsondata[i]["Username"]) + '"/> </td>';

            row$ += '<td> ' + (jsondata[i]["Password"] == null ? "" : jsondata[i]["Password"]) + ' ';
            row$ += '<input type="hidden" id="hdnPassword" name="hdnPassword" value = "' + (jsondata[i]["Password"] == null ? "" : jsondata[i]["Password"]) + '"/> </td>';

         
            $(tableid).append(row$);
        }

        $('.dataTables_filter input').attr("placeholder", "Search");
        $('.dataTables_filter input').wrap('<div class="input-group" />');

        if (flag == 1) {
            $('#dvExcelDataList_imp').hide();
            $('#dvExcelColumnsCheck_imp').hide();
            toastr.warning('Somewhere Data is not in Correct Format, Please Click on Verify Data to Check', 'Warning!');
            // $('#divLoading_imp').hide();
            return false;
        }
        else {
            $('#dvExcelDataList_imp').show();
            $('#dvExcelColumnsCheck_imp').hide();
            jsonDt = jsondata;
            SaveDataTemp_imp();
            //$('#divLoading_imp').show();
        }
    }
    var ClearMessage_imp = function () {
       
        $("#UploadedFile_imp").val("");
     /*   $('#UploadedFile_imp').val('').clone(true);*/
        $('#btnImportData').attr("disabled", false)
        $("#btnImportData").text("Import Data");
    };
   
    var BindColumnsTable_imp = function (jsondata, tableid) {

        $('#dvExcelColumnsCheck_imp').show();
        var columnSet = [];
        flag = 0;
        var rowHash = jsondata[0]; var Rowcount = 0;
        for (var key in rowHash) {
            if (rowHash.hasOwnProperty(key)) {
                if ($.inArray(key, columnSet) == -1) {/*Adding each unique column names to a variable array*/
                    Rowcount = Rowcount + 1;
                    if (key == 'MobileNo' || key == 'EmailId' || key == 'Username' || key == 'Password') {

                        if (Rowcount == 1) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>MobileNo</b></td><td><span style="color:green" class="fa fa-check-circle"></span></td></tr>');
                        }
                        else if (Rowcount == 2) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>EmailId</b></td><td><span style="color:green" class="fa fa-check-circle"></span></td></tr>');
                        }
                        else if (Rowcount == 3) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>Username</b></td><td><span style="color:green" class="fa fa-check-circle"></span></td></tr>');
                        }
                        else if (Rowcount == 4) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>Password</b></td><td><span style="color:green" class="fa fa-check-circle"></span></td></tr>');
                        }
                       
                    }
                    else {

                        flag = 1;
                        if (Rowcount == 1) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>MobileNo</b></td><td><span style="color:red" class="fa fa-times-circle"></span></td></tr>');
                        }
                        else if (Rowcount == 2) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>EmailId</b></td><td><span style="color:red" class="fa fa-times-circle"></span></td></tr>');
                        }
                        else if (Rowcount == 3) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>Username</b></td><td><span style="color:red" class="fa fa-times-circle"></span></td></tr>');
                        }
                      
                        else if (Rowcount == 4) {
                            $('#tbodyExcelColumns_imp').append('<tr><td><b>Password</b></td><td><span style="color:red" class="fa fa-times-circle"></span></td></tr>');
                        }
                    }

                }
            }
        }

        if (Rowcount > 4) {
            alert('Number of Columns is More than 4', 'Warning!');
            //$('#divLoading_imp').hide();
            return false;
        }
        if (Rowcount < 4) {
            alert('Number of Columns is Less than 4', 'Warning!');
            //$('#divLoading_imp').hide();
            return false;
        }
        $('#dvExcelDataList_imp').hide();

        if (flag == 0) {
            BindRowsTable_imp(jsondata, tableid);
        }
    }
    var BindRowsTable_imp = function (jsondata, tableid) {

        // $('#thHeading').click();
        var rows = 1;
        var FirstNamerowno = ""; var MiddleNamerowno = ""; var LastNamerowno = ""; var UserNamerowno = ""; var MobileNorowno = "";
        var EmailIdrowno = ""; var Passwordrowno = "";
        var EmailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var ValideMob = /^\d{10}$/;

        var letters = /^[A-Za-z. ]+$/;
        rows = 1;
        for (var j = 0; j < jsondata.length; j++) {
            var acont = 0;
            rows = rows + 1;
            var MobileNo = jsondata[j]["MobileNo"];
            var EmailId = jsondata[j]["EmailId"];
            var UserName = jsondata[j]["Username"];
            var Password = jsondata[j]["Password"];
            var regex1 = /^\d+(?:\.\d\d?)?$/;
            var regex = /^(0|[1-9][0-9]*)$/;


            if (MobileNo == "" || MobileNo == null || MobileNo == 0) {
                flag = 1;
                btnImportFlag = 1;
                if (MobileNorowno == "") {
                    MobileNorowno = MobileNorowno + rows;
                }
                else {
                    MobileNorowno = MobileNorowno + ", " + rows;
                }
            }
            else {
                if (!(ValideMob.test(MobileNo))) {
                    flag = 1;
                    btnImportFlag = 1;
                    if (MobileNorowno == "") {
                        MobileNorowno = MobileNorowno + rows;
                    }
                    else {
                        MobileNorowno = MobileNorowno + ", " + rows;
                    }
                }
            }

            if (EmailId != null) {  //Making optional if value entered then only check format of email
                if (!(EmailRegex.test(EmailId))) {
                    flag = 1;
                    btnImportFlag = 1;
                    if (EmailIdrowno == "") {
                        EmailIdrowno = EmailIdrowno + rows;
                    }
                    else {
                        EmailIdrowno = EmailIdrowno + ", " + rows;
                    }
                }
            }
            //}

            if (UserName == "" || UserName == null || UserName == 0) {
                flag = 1;
                btnImportFlag = 1;
                if (UserNamerowno == "") {
                    UserNamerowno = UserNamerowno + rows;
                }
                else {
                    UserNamerowno = UserNamerowno + ", " + rows;
                }
            }
            else {
                if ((UserName.length < 6 || UserName.length > 16)) {
                    flag = 1;
                    btnImportFlag = 1;
                    if (UserNamerowno == "") {
                        UserNamerowno = UserNamerowno + rows;
                    }
                    else {
                        UserNamerowno = UserNamerowno + ", " + rows;
                    }
                }
            }

            if (Password == "" || Password == null || Password == 0) {
                flag = 1;
                btnImportFlag = 1;
                if (Passwordrowno == "") {
                    Passwordrowno = Passwordrowno + rows;
                }
                else {
                    Passwordrowno = Passwordrowno + ", " + rows;
                }
            }
            else {
                if ((Password.length < 6 || Password.length > 16)) {
                    flag = 1;
                    btnImportFlag = 1;
                    if (Passwordrowno == "") {
                        Passwordrowno = Passwordrowno + rows;
                    }
                    else {
                        Passwordrowno = Passwordrowno + ", " + rows;
                    }
                }
            }
        }

        var rowscount = 0;
        $('#ExcelColumns_imp tbody tr').each(function () {

            rowscount = rowscount + 1;
            if (rowscount == 1) {
                $(this).append('<td>' + (MobileNorowno == "" ? "<span style='color:green;font:bold'>All Correct</span>" : '<span style="color:red;font:bold">' + MobileNorowno + '</span>') + '</td>');
                $(this).append('<td><b>This field is compulsory, Allow 10 digits number only.</b></td>');
            }
            else if (rowscount == 2) {
                $(this).append('<td>' + (EmailIdrowno == "" ? "<span style='color:green;font:bold'>All Correct</span>" : '<span style="color:red;font:bold">' + EmailIdrowno + '</span>') + '</td>');
                $(this).append('<td><b>This field is compulsory, Allow email address in proper format.</b></td>');
            }
            else if (rowscount == 3) {
                $(this).append('<td>' + (UserNamerowno == "" ? "<span style='color:green;font:bold'>All Correct</span>" : '<span style="color:red;font:bold">' + UserNamerowno + '</span>') + '</td>');
                $(this).append('<td><b>This field is compulsory, username should be minimum 6 and maximum 16 character..</b></td>');
            }
            else if (rowscount == 4) {
                $(this).append('<td>' + (Passwordrowno == "" ? "<span style='color:green;font:bold'>All Correct</span>" : '<span style="color:red;font:bold">' + Passwordrowno + '</span>') + '</td>');
                $(this).append('<td><b>This field is compulsory, password should be minimum 6 and maximum 16 character.</b></td>');
            }
            else if (rowscount == 5) {
                $(this).append('<td><span style="color:blue"><b>As Per Excel</b></span></td>');
                $(this).append('<td><b>This field is not compulsory, Allow alpha-numeric value</b></td>');
            }
        });


        if (btnImportFlag == 1) {
            $("#btnImportData").prop("disabled", "disabled");
        }
        if (flag == 0) {
            if (UserNamerowno == "" && MobileNorowno == "" && EmailIdrowno == "") {
                $("#btnImportData").removeAttr("disabled", "disabled");
                DisplayExcelData(jsondata, '#exceltable_imp');
            }
        }
        // $('#divLoading_imp').hide();
    }
    $('#btnCancel').click(function () {
        ClearMessage_imp();
        $('#dvExcelColumnsCheck_imp').hide();
        $('#dvExcelDataList_imp').hide();
        $('#exceltable_imp').empty();
        var flag = 0; var buttonType = "", jsonDt = "";
        //$('#divLoading_imp').hide();

    });
    var rowCount = function (sURLVariables) {
        var row = 0;
        for (var i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split(':');
            if (sParameterName[0].indexOf("{") != -1) {
                row++;
            }
        }
        return row;
    }
    $.fn.rowCount = function () {
        return $('tr', $(this).find('tbody')).length;
    };

    $.fn.columnCount = function () {
        return $('th', $(this).find('tbody')).length;
    };
    var SaveDataTemp_imp = function () {

        var rowctr = $('#exceltable_imp').rowCount();
        var colctr = 8;
        if (rowctr <= 0) {
            toastr.warning('Data not found! Have you Import the data from Excel?', 'Warning!');
            return false;
        }

        if (colctr > 8) {
            toastr.warning('Number of Columns in Excel is More than the Format', 'Warning!');
            return false;
        }

        if (colctr < 8) {
            toastr.warning('Number of Columns in Excel is Less than the Format', 'Warning!');
            return false;
        }

        
        var count = 0;
        var dataTable = '';

        var c = 0, rowscount = 0;
        while (rowctr > 0) {
            dataTable = '[{';
            if (rowctr >= 1000) {
                rowctr = rowctr - 1000;
                rowscount = rowscount + 1000;
            }
            else {
                rowscount = rowscount + rowctr;//- 1;
                rowctr = 0;
            }

            for (i = c; i < rowscount; i++) {
                c = c + 1;
                //var CandidateExId = 0;               

                var MobileNo = jsonDt[i]["MobileNo"] == null ? "" : jsonDt[i]["MobileNo"];
                var EmailId = jsonDt[i]["EmailId"] == null ? "" : jsonDt[i]["EmailId"];

                var Username = jsonDt[i]["Username"] == null ? "" : jsonDt[i]["Username"];
                
                var Password = jsonDt[i]["Password"] == null ? "" : jsonDt[i]["Password"];
                if (dataTable == '[{') {
                    dataTable = dataTable + '"MobileNo":"' + MobileNo + '","EmailId":"' + EmailId + '","Username":"' + Username + '","Password":"' + Password + '"}';
                }
                else {
                    dataTable = dataTable + ',{ "MobileNo":"' + MobileNo + '","EmailId":"' + EmailId + '","Username":"' + Username + '","Password":"' + Password + '"}';
                }
            }

            var flag = 1;
            dataTable = dataTable + ']';
            var UserData = JSON.parse(dataTable);

            var url = '/Home/InsertExcelData/';
            var jqxhr = $.post(url, { UserData: JSON.stringify(UserData)}, 'json'
            ).done(function (data) {

                flag = 1;
                alert("Data Imported Successfully");
                ClearMessage_imp();
                var html = '';
                var j = 1;
                if (data.length > 0) {
                    //$('#exceltable_imp tbody').empty();
                    //for (var i = 0; i < data.length; i++) {
                    //    html += '<tr><td style="text-align: left">' + parseInt(j + i) + '</label></td>';
                    //    html += '<td style="text-align: left">' + data[i].MobileNo + '</label></td>';
                    //    html += '<td style="text-align: left">' + data[i].EmailId + '</label></td>';
                    //    if (data[i].UserStatus == "User Already Exist") {
                    //        html += '<td style="text-align: left;">' + data[i].UserName + '</label>&nbsp;<label style="color:red">=>' + data[i].UserStatus + '</label></td>';
                    //    }
                    //    else {
                    //        html += '<td style="text-align: left;">' + data[i].UserName + '</label>&nbsp;<label style="color:green">=>' + data[i].UserStatus + '</label></td>';
                    //    }
                    //    html += '</tr>';
                    //}
                    //$('#tbodyexceltable_imp').append(html);
                    //$('#importMessageAllSuccess').css('display', 'none');
                    //$('#importMessagePartial').css('display', 'block');
                    $('#btnImportData').text("Import Data");
                    $('#dvExcelColumnsCheck_imp').hide();
                    $('#dvExcelDataList_imp').show();
                   
                    $('#UploadedFile_imp').removeAttr("disabled");
                    $('#btnViewData').removeAttr("disabled");

                    ClearMessage_imp();
                }
                else if (data == 0) {
                    //$('#importMessagePartial').css('display', 'none');
                    //$('#importMessageAllSuccess').css('display', 'block');
                    $('#divLoading_imp').hide();
                    $('#btnImportData').text("Import Data");
                    $('#btnImportData').attr("disabled", "disabled");
                    $('#UploadedFile_imp').removeAttr("disabled");
                    $('#btnViewData').removeAttr("disabled");
                }


            }).fail(function (data) {
                flag = 0;
                //alert("error");
            }).always(function (data) {
                flag = 1;
                //alert("finished");
            });

            // Set another completion function for the request above
            jqxhr.always(function (data) {
                //alert("second finished");
            });

            if (flag == 0) {
                break;
            }

            return flag;
        }

    };

    var Datacheck_imp = function () {

        $('#tbodyExcelColumns_imp').empty();
        $('#exceltable_imp').empty();

        var regex = /\.(xlsx|xls)$/i;
        // olg reg ex   /^([a-zA-Z0-9\s_\\.\-:])+(.xlsx|.xls)$/;
        var fileUpload = $("#UploadedFile_imp")[0];
        /*Checks whether the file is a valid excel file*/
        if (regex.test($("#UploadedFile_imp").val().toLowerCase())) {
            var xlsxflag = false; /*Flag for checking whether excel is .xls format or .xlsx format*/
            if ($("#UploadedFile_imp").val().toLowerCase().indexOf(".xlsx") > 0) {
                xlsxflag = true;
            }
            /*Checks whether the browser supports HTML5*/
            if (typeof (FileReader) != "undefined") {
                var reader = new FileReader();

                //if (reader.readAsBinaryString) {

                reader.onload = function (e) {
                    var data = e.target.result;
                    /*Converts the excel data in to object*/
                    if (xlsxflag) {
                        var workbook = XLSX.read(data, { type: 'binary' });
                    }
                    else {
                        var workbook = XLS.read(data, { type: 'binary' });
                    }
                    /*Gets all the sheetnames of excel in to a variable*/
                    var sheet_name_list = workbook.SheetNames;

                    var WkSheetName = sheet_name_list[0];

                    var cnt = 0; /*This is used for restricting the script to consider only first sheet of excel*/

                    if (xlsxflag) {
                        var exceljson = XLSX.utils.sheet_to_json(workbook.Sheets[WkSheetName]);
                    }
                    else {
                        //CHANGE BY POONAM PISEY - DUE TO VALUE OF DATE IS NOT PROPER
                        var exceljson = XLS.utils.sheet_to_row_object_array(workbook.Sheets[WkSheetName], { defval: null });
                        //var exceljson = XLS.utils.sheet_to_json(workbook.Sheets[WkSheetName], { raw: true, defval: null });
                    }

                    if (exceljson.length > 0 && cnt == 0) {

                        BindColumnsTable_imp(exceljson, '#ExcelColumns');
                        //DisplayExcelData(exceljson, '#ExcelColumns');
                        cnt++;
                    }

                    $('#ExcelColumns_imp').show();
                }
                if (xlsxflag) {/*If excel file is .xlsx extension than creates a Array Buffer from excel*/
                    reader.readAsArrayBuffer($("#UploadedFile_imp")[0].files[0]);
                }
                else {
                    reader.readAsBinaryString($("#UploadedFile_imp")[0].files[0]);
                }
                //reader.readAsBinaryString(fileUpload.files[0]);
                //}
            }
            else {
                toastr.warning('Sorry! Your Browser does not Support HTML5', 'Warning!');
                return false;
            }
        }
        else {
            toastr.warning('Please Upload a Valid Excel File', 'Warning!');
            return false;
        }
    }
    var BindTableHeader_imp = function (jsondata, tableid) {/*Function used to get all column names from JSON and bind the html table header*/

        var columnSet = [];
        var dataTable = '';
        var count = 0;
        var headerTr$ = $('<tr style="background-color:#000; color:#fff" />');
        for (var i = 0; i < jsondata.length; i++) {
            var rowHash = jsondata[i]; 0
            for (var key in rowHash) {
                if (rowHash.hasOwnProperty(key)) {

                    if ($.inArray(key, columnSet) == -1) {/*Adding each unique column names to a variable array*/
                        columnSet.push(key);

                        if (key == 'MobileNo') {
                            headerTr$.append($('<th class="text-center" style="padding:7px; border:1px solid"/>').html('Sr. No.'));
                        }
                        if (key == 'MobileNo') {
                            headerTr$.append($('<th class="text-center" style="padding:7px; border:1px solid"/>').html(key));
                        }
                        else if (key == 'EmailId') {
                            headerTr$.append($('<th class="text-center" style="padding:7px; border:1px solid"/>').html(key));
                        }
                        else if (key == 'Username') {
                            headerTr$.append($('<th class="text-center" style="padding:7px; border:1px solid"/>').html(key));
                        }
                        else if (key == 'Password') {
                            headerTr$.append($('<th class="text-center" style="padding:7px; border:1px solid"/>').html(key));
                        }
                        else {
                            count = count + 1;
                            if (dataTable == '') {
                                dataTable = dataTable + key;
                            }
                            else {
                                dataTable = dataTable + ', ' + key;
                            }
                        }
                    }
                }
            }
        }

        if (count > 0) {
            dataTable = dataTable + '}]';
            alert("Following columns are not matching :-\n " + dataTable);
            return false;
        }
        $(tableid).append(headerTr$);
        return columnSet;
    }
    $('#btnCancel_imp').click(function () {
        ClearMessage_imp();
        $('#dvExcelColumnsCheck_imp').hide();
        $('#dvExcelDataList_imp').hide();
        $('#exceltable_imp').empty();
        var flag = 0; var buttonType = "", jsonDt = "";
        //$('#divLoading_imp').hide();

    });
    return {
        Init: Init,
    }

}();



