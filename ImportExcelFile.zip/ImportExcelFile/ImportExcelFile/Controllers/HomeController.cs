﻿using ImportExcelFile.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ImportExcelFile.Controllers
{
    public class HomeController : Controller
    {
        DBconnection cn = new DBconnection();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult InsertExcelData(string UserData)
        {
            
            List<VMImportUser> vmImportUser = (List<VMImportUser>)JsonConvert.DeserializeObject(UserData, (typeof(List<VMImportUser>)));
            VMImportData obj = new VMImportData();
            obj.ImportUser = vmImportUser;
            string fieldjson = JsonConvert.SerializeObject(obj.ImportUser);
            DataTable dt = JsonConvert.DeserializeObject<DataTable>(fieldjson);

            try
            {
                var con = cn.connect();
                SqlCommand cmd = new SqlCommand("[dbo].[ImportData]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserDefineTable", dt);
                var i = cmd.ExecuteNonQuery();
                return Json(i,JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

               throw;
                
            }
            
        }
        

    }
}