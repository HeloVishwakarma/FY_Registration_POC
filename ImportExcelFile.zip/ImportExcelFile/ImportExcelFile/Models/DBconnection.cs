﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ImportExcelFile.Models
{
    public class DBconnection
    {
        public SqlConnection connect()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}