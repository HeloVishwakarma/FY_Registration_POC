﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMSEmailCrud.Models
{
    public class VMEmail
    {
        public string senderEmail { get; set; }
        public string receiverEmail { get; set; }
        public string password { get; set; }
        public string collegeName { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
        public string senderEmailPassword { get; set; }
        public string SMSURL { get; set; }
        public string SMSUser { get; set; }
        public string SMSPassword { get; set; }
        public string UserName { get; set; }
        public string receiverMobileNumber { get; set; }
        public Boolean IsSMS { get; set; }
        public Boolean IsEmail { get; set; }
        public bool IsUserExist { get; set; }
        public string ShortName { get; set; }
        public string TemplateId { get; set; }
        public string SenderId { get; set; }
        public int SMSAPITYPE { get; set; }
        public string ReportName { get; set; }
    }
}