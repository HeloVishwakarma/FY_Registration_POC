﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMSEmailCrud.Models
{
    public class VMAppSettings
    {
        public string baseUrl { get; set; }
        public string baseUrlLogin { get; set; }
        public int masterCollegeId { get; set; }
        public string defaultImage { get; set; }
        public string connectionStringReport { get; set; }
        public string azureBlobBaseUrl { get; set; }
        public string azureBlobConnection { get; set; }
        public string PaymentMode { get; set; }
        public string SENDGRIDAPIKEY { get; set; }
        public string TEXTLOCALSMSKEY { get; set; }
        public string TenantId { get; set; }
        public string AppId { get; set; }
        public string ClientSecret { get; set; }
        public string Url { get; set; }
    }
}