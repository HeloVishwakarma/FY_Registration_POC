﻿using SMSEmailCrud.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace SMSEmailCrud.Common
{
    public class SMS
    {
        public static void SendSMS(VMEmail sms)
        {

            if (sms.SMSAPITYPE == 2)
            {
                string result = sendTextLocalSMS(sms);
            }
            else
            {
                WebRequest request = HttpWebRequest.Create("" + sms.SMSURL + "?ID=" + sms.SMSUser + "&PWD=" + sms.SMSPassword + "&PHNO=" + sms.receiverMobileNumber + "&TEXT=" + sms.message + "&TemplateID=" + sms.TemplateId + "");
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string urlText = reader.ReadToEnd();
            }
              
        }
        public static string sendTextLocalSMS(VMEmail sms)
        {
            String result;
            string apiKey = AppSettingsReaders.GetAppSettings().TEXTLOCALSMSKEY;
            string numbers = sms.receiverMobileNumber; // in a comma seperated list
            string message = sms.message;
            string sender = sms.SenderId;

            //String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
            String url = "" + sms.SMSURL + "?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
            //refer to parameters to complete correct url string

            StreamWriter myWriter = null;
            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

            objRequest.Method = "POST";
            objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
            objRequest.ContentType = "application/x-www-form-urlencoded";
            try
            {
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(url);
            }
            catch (Exception e)
            {
                return e.Message;
            }
            finally
            {
                myWriter.Close();
            }

            HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
            using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
            {
                result = sr.ReadToEnd();
                // Close and clean up the StreamReader
                sr.Close();
            }
            return result;
        }
    }
}