﻿using SMSEmailCrud.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SMSEmailCrud.DbConnection;
using System.Threading.Tasks;
using SMSEmailCrud.Common;


namespace SMSEmailCrud.Controllers
{
    public class HomeController : Controller
    {

        Connection cn = new Connection();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        long count;
        [HttpPost]
        public async Task<JsonResult> CheckUserName(RegistrationLoginModel obj)
        {
            object ret =await CheckUser(obj);
            return Json(ret, JsonRequestBehavior.AllowGet);
        }
        public async Task<string> CheckUser(RegistrationLoginModel obj)
        {
            var con = cn.connect();
            try
            {
                SqlCommand cmd = new SqlCommand("Usp_Registration", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@CommandType", "CheckUserName");
                string ret = cmd.ExecuteScalar().ToString();
                return ret;
            }
            catch (Exception)
            {
                throw;
                
            }
           
        }
        [HttpPost]
        public async Task<ActionResult> Registration(RegistrationLoginModel obj)
        {
            long i = await UserRegistration(obj);
            if(i == 1)
            {

                VMEmail sendSMSData = new VMEmail();
                sendSMSData.UserName = obj.UserName;
                sendSMSData.receiverMobileNumber = obj.MobileNo;
                sendSMSData.message = "Dear Student, Thank you for showing interest for ACE Your username:"+obj.UserName+" Password:"+ obj.Password+" MSERP";
                sendSMSData.SMSAPITYPE = 1;
                sendSMSData.SMSPassword = "iitmsTEST@5448";
                sendSMSData.SMSURL = "http://smsnmms.co.in/sms.aspx";
                sendSMSData.SMSUser = "hr@iitms.co.in";
                sendSMSData.TemplateId = "1007046786440602413";

                SMS.SendSMS(sendSMSData);
            }
            return Json(i, JsonRequestBehavior.AllowGet);
        }
        public async  Task<long> UserRegistration(RegistrationLoginModel obj)
        {
            var con = cn.connect();
            try
            {
                

                SqlCommand cmd = new SqlCommand("Usp_Registration", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", obj.UserName);
                cmd.Parameters.AddWithValue("@MobileNo", obj.MobileNo);
                cmd.Parameters.AddWithValue("@Email", obj.Email);
                cmd.Parameters.AddWithValue("@Password", obj.Password);
                cmd.Parameters.AddWithValue("@CommandType", "Register");
                object ret = cmd.ExecuteNonQuery();
                return (int)ret;
            }
            catch (Exception)
            {

                throw;
            }
        }
        
    }
}