﻿using Newtonsoft.Json;
using SMSEmailCrud.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SMSEmailCrud
{
    public class AppSettingsReaders
    {
        static string projPath = string.Empty;
        public static VMAppSettings GetAppSettings()
        {
            VMAppSettings appSettings = new VMAppSettings();
            try
            {
                projPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServiceProvider\\appsettings.json");
                using (StreamReader r = new StreamReader(projPath))
                {
                    string json = r.ReadToEnd();
                    appSettings = JsonConvert.DeserializeObject<VMAppSettings>(json);
                }
            }
            catch (System.Exception ex)
            {
            }
            return appSettings;
        }
    }
}