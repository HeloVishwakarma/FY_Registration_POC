﻿using SendGrid;
using SendGrid.Helpers.Mail;
using SMSEmailCrud.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SMSEmailCrud.Email
{
    public class Email
    {
        public static async Task SendEmail(VMEmail email)
        {
            try
            {
                if (email.receiverEmail != null && email.receiverEmail != "")
                {
                    var apiKey = AppSettingsReaders.GetAppSettings().SENDGRIDAPIKEY;
                    //var apiKey = WebConfigurationManager.AppSettings["SENDGRID_API_KEY"];
                    // var apiKey = Environment.GetEnvironmentVariable("SENDGRID_API_KEY");
                    var client = new SendGridClient(apiKey);
                    var msg = new SendGrid.Helpers.Mail.SendGridMessage()
                    {
                        From = new EmailAddress("noreply@mastersofterp.in"),
                        Subject = email.subject,
                        PlainTextContent = email.message,
                        HtmlContent = null,
                    };
                    msg.AddTo(new EmailAddress(email.receiverEmail));
                    var response = await client.SendEmailAsync(msg).ConfigureAwait(false);

                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}