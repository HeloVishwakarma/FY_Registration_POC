﻿var Employee = function () {
   
    var init = function () {
        GetDepartment();
        loaddata();
        BindEvents();
    }
    var GetDepartment = function () {
        $.ajax({
            type: "GET",
            url: "/Home/GetDepartment",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                console.log(data);
              
                $.each(data, function () {
                    $('#ddlDepartment').append($("<option />").val(this.DepartmentID).text(this.DepartmentName));
                });
                $('#ddlDepartment').multiselect('rebuild');
            },
            error: function (response) {
                alert(response.d);
            }
        })
    }
    var loaddata = function () {
        $.ajax({
            type: "GET",
            url: "/Home/LoadData",
            data: '{}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: OnSuccess,
            failure: function (response) {
                alert(response.d);
            },
            error: function (response) {
                alert(response.d);
            }
        });
    };
    var OnSuccess = function (response) {
        $("#tblCustomers").DataTable(
            {

                bLengthChange: true,
                lengthMenu: [[5, 10, -1], [5, 10, "All"]],
                bFilter: true,
                bSort: true,
                bPaginate: true,
                data: response,
                destroy: true,
                columns: [
                    { 'data': 'EmployeeID' },
                    { 'data': 'EmployeeName' },
                    { 'data': 'Email' },
                    { 'data': 'DepartmentName' },
                    { 'data': 'EmployeeID', "width": "150px", "render": function (EmployeeID) { return '<button type="button" data-toggle="modal" data-target="#myModal"  class="btn btn-primary"onclick="return GetbyID(' + EmployeeID + ')"><i class="fa fa-edit">&nbspUpdate</i></button>&nbsp<button type="button"  class="btn btn-danger"onclick="Delete(' + EmployeeID + ')"><i class="fa fa-trash">&nbspDelete</i></button>' } }]
            });
    }
    $("#AddEmp").click(function () {
        if ($("#Name").val() == '') {
            alert("Please Enter Employee Name")
            $("#Name").focus();
            return false;
        }
        var emailVal = $("#Email").val();
        if (emailVal == "") {
            alert("Please Enter Email")
            $("#Email").focus();
            return false;
        }
        else {
            var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (filter.test(emailVal)) {
            }
            else {
                alert("Please Enter email in Correct Format!");
                $('#Email').focus();
                return false;
            }
        }
        if ($("#ddlDepartment").val() == '') {
            alert("Please Select Department")
            $("#ddlDepartment").focus();
            return false;
        }
        var Courselist = new Array();
        var Course = "";
        var selectCourse = $("#ddlDepartment option:selected");
        selectCourse.each(function () {
            Course += $(this).val() + "$";
        });
        var empObj = {
            EmployeeID: $('#EmployeeID').val(),
            EmployeeName: $('#Name').val(),
            Email: $("#Email").val(),
            DepartmentIDs: Course
        };
        console.log(empObj);
        $.ajax({
            url: "/Home/AddEmployee",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(empObj),
            contentType: "application/json;charset=utf-8",
            success: function (result) {
                alert("Employee Added")
                clearTextBox();
                loaddata();
            },
            error: function (errormessage) {
                alert("Somthing went wrong");
            }

        });

    })
    $("#btnModel").click(function () {
        clearTextBox();
    })
    function clearTextBox() {
        $('#EmployeeID').val("");
        $('#Name').val("");
        $('#Email').val("");
        $("#ddlDepartment option:selected").removeAttr("selected");
        $("#ddlDepartment").multiselect("refresh");
        $('#AddEmp').text("Save");
    }
    $("#Cancel").click(function () {
        $('#EmployeeID').val("");
        $('#Name').val("");
        $('#Email').val("");
        $("#ddlDepartment").multiselect("clearSelection");
        $("#ddlDepartment").multiselect('refresh');
        $("#ddlDepartment").multiselect("rebuild");
        $('#AddEmp').text("Save");
    })
    var loadEmployeeData = function (result) {
        console.log(result);
        $('#EmployeeID').val(result[0].EmployeeID);
        $('#Name').val(result[0].EmployeeName);
        $('#Email').val(result[0].Email);
        $('#ddlDepartment').val([result[0].DepartmentID]);
        $("#ddlDepartment").multiselect("refresh");
        $("#ddlDepartment").multiselect("disable");
        $('#AddEmp').text("Update");

    }
    var BindEvents = function () {
        $('form#InputForm').submit(function () {
            if ($("#ddlDepartment").val() == 0) {
                $('#ddlDepartment').focus();
                alert("Please Select Department!");
                return false;
            }
            //$('#btnExportExcel').text(" ..Processing");
            //$('#btnExportExcel').attr("disabled", "disabled");

            ExportRequestParams();
        });
    };
    var ExportRequestParams = function () {
        var Courselist = new Array();
        var Course = "";
        var selectCourse = $("#ddlDepartment option:selected");
        selectCourse.each(function () {
            Course += $(this).val() + "$";
        });
        $('#Department').val(Course);
    };
    return {
        Init: init,
        LoadEmployeeData: loadEmployeeData,
        Loaddata: loaddata
    }
}();

