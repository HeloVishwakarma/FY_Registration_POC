﻿
var RenderDropDown = function (control, data, id, value) {
    data = sortResults(data, value, true);
    control.empty();
    $.each(data, function () {
        control.append($("<option />").val(this[id]).text(this[value]));
        //if(id == 'BasicCourseId')
            //console.log(this[value]);
    });
    control.prepend($("<option selected='selected' />").val(0).text("Please Select"));
};

var RenderDropDownWithOther = function (control, data, id, value) {
    data = sortResults(data, value, true);
    control.empty();
    $.each(data, function () {
        control.append($("<option />").val(this[id]).text(this[value]));
    });
    control.prepend($("<option selected='selected' />").val(0).text("Please Select"));
    control.append($("<option/>").val(-999).text("Other"));
};

var sortResults = function (data, prop, asc) {
    data.sort(function (a, b) {
        if (asc) {
            return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
        } else {
            return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
        }
    });
    return data;
}

//function IsNumeric(evt) {
//    var invalidChars = /([^0-9" "._-])/gi
//    if (invalidChars.test(evt.value)) {
//        evt.value = evt.value.replace(invalidChars, "");
//        $("#errmsg").html("Digits Only").show().fadeOut("slow");
//        return false;
//    }
//    else {
//        return true;
//    }
//}

function IsNumeric(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
};

function CheckValidPassword(password) {
    var upperCase = new RegExp('[A-Z]');
    var lowerCase = new RegExp('[a-z]');
    var numbers = new RegExp('[0-9]');
    var special = new RegExp("^[a-zA-Z0-9]+$");

    if (($.trim(password).length >= 6) && password.match(upperCase) && password.match(lowerCase) && password.match(numbers) && !special.test(password)) {
        return true;
    }
    else {
        return false;
    }
};

function IsFloatNumber(evt) {
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
        event.preventDefault();
    }
};

var IsValidEmail = function (email) {
    if (email == "") {
    }
    else {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filter.test(email)) {
            return true;
        }
        else {
            return false;
        }
    }
}

var GetLogOutUrl = function () {
    return "/StudentLogin/Index/";
}

var GetAPIURL = function () {
    //return "http://192.168.0.15:8084/";
    return "https://cloudmvcapi.mastersofterp.in/";
    //return "http://localhost:50794/";
    //return "https://cimsapi.mastersofterp.in/";
}

var ShowReport = function (data) {
    window.open("/CommonReport/ShowGeneralReport?data=" + JSON.stringify(data), 'mywindow', 'fullscreen=yes, scrollbars=auto');
}

var GoBack = function () {
    window.history.pushState(null, "", window.location.href);
    window.onpopstate = function () {
        window.history.pushState(null, "", window.location.href);
    };
}