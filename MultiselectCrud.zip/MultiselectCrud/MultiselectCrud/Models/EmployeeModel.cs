﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MultiselectCrud.Models
{
    public class EmployeeModel
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Email { get; set; }
        public  string DepartmentName { get; set; }
        public string DepartmentIDs { get; set; }
        public int DepartmentID { get; set; }
    }
}