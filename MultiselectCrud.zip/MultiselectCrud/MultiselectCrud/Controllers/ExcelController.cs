﻿using ClosedXML.Excel;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.Mvc;

namespace MultiselectCrud.Controllers
{
    public class ExcelController : Controller
    {
        DataSet ds;
        DataTable dt;
        public SqlConnection connect()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception)
            {

                throw;
            }

        }
        [HttpPost]
        public ActionResult ExportToExcel(string DepartmentIDs)
        {
            var cn = connect();

            try
            {
                string depid = DepartmentIDs.Remove(DepartmentIDs.Length - 1);
                string reportName = null;
                DataSet ds = null;
                DataTable data = new DataTable();
                var av = new System.Web.UI.WebControls.GridView();
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DepartmentID", depid);
                cmd.Parameters.AddWithValue("@Action", "ExportExcel");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds);
                using (XLWorkbook wb = new XLWorkbook())
                {
                    if (ds.Tables[0] != null)
                    {

                        wb.Worksheets.Add(ds.Tables[0]);
                    }
                    using (MemoryStream stream = new MemoryStream())
                    {
                        if (ds.Tables[0] != null)
                        {
                            wb.SaveAs(stream);
                        }
                        //reportName = "Feedback Consolidated Report.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", reportName);
                    }
                }

            }

            catch (Exception)
            {

                throw;
            }
            return null;
        }
        [HttpPost]
        public JsonResult SaveExcelData(string Data, string DepartmentIDs)
        {
            return null;
        }



    }
}
//if (ds.Tables[0].Rows.Count != 0)
//{
//    data = ds.Tables[0];
//}
//av.DataSource = data;
//av.DataBind();
//System.IO.StringWriter sw = new System.IO.StringWriter();
//System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);
//av.RenderControl(htw);
//byte[] bindata = System.Text.Encoding.ASCII.GetBytes(sw.ToString());
//return File(bindata, "application/ms-excel", "ExcelReport.xls");