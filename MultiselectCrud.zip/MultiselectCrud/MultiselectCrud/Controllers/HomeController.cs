﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using MultiselectCrud.Models;


namespace MultiselectCrud.Controllers
{
    public class HomeController : Controller
    {
        public SqlConnection connect()
        {
            try
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception)
            {

                throw;
            }

        }
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetDepartment()
        {

            List<DepartmentModel> emp = GetDepartmentList();
            return Json(emp, JsonRequestBehavior.AllowGet);

        }
        public List<DepartmentModel> GetDepartmentList()
        {
            var cn = connect();
            List<DepartmentModel> list = new List<DepartmentModel>();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "GetDepartment");
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DepartmentModel dep = new DepartmentModel();
                    dep.DepartmentID = Convert.ToInt32(dr["DepartmentID"].ToString());
                    dep.DepartmentName = dr["DepartmentName"].ToString();
                    list.Add(dep);

                }
                return list;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult LoadData()
        {

            List<EmployeeModel> emp = GetData();
            return Json(emp, JsonRequestBehavior.AllowGet);

        }
        public List<EmployeeModel> GetData()
        {
            var cn = connect();
            List<EmployeeModel> list = new List<EmployeeModel>();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "GetEmployeeData");
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    EmployeeModel emp = new EmployeeModel();

                    emp.EmployeeID = Convert.ToInt32(dr["id"].ToString());
                    emp.EmployeeName = dr["EmployeName"].ToString();
                    emp.Email = dr["Email"].ToString();
                    emp.DepartmentName = dr["DepartmentName"].ToString();
                    
                    //emp.Action = "<a class='btn btn-primary fa fa-edit'   href='index" + ( new { Id = emp.id }) + "'data-toggle='modal' data-target='#myModal'>Update</a>&nbsp<a class='btn btn-danger fa fa-trash' href='" + ("Index", "Home", new { Id = emp.id }) + "'>Delete</a>";
                    list.Add(emp);

                }
                return list;

            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult GetbyID(int empID)
        {
            List<EmployeeModel> emp = GetEmployee(empID);
            return Json(emp, JsonRequestBehavior.AllowGet);

        }
        public List<EmployeeModel> GetEmployee(int empID)
        {
            List<EmployeeModel> list = new List<EmployeeModel>();
            DataTable dt = new DataTable();
            var cn = connect();
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id",empID);
                cmd.Parameters.AddWithValue("@Action", "GetEmployebyID");
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    EmployeeModel emp = new EmployeeModel();

                    emp.EmployeeID = Convert.ToInt32(dr["id"].ToString());
                    emp.EmployeeName = dr["EmployeName"].ToString();
                    emp.Email = dr["Email"].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr["DepartmentID"].ToString());

                    //emp.Action = "<a class='btn btn-primary fa fa-edit'   href='index" + ( new { Id = emp.id }) + "'data-toggle='modal' data-target='#myModal'>Update</a>&nbsp<a class='btn btn-danger fa fa-trash' href='" + ("Index", "Home", new { Id = emp.id }) + "'>Delete</a>";
                    list.Add(emp);

                }
                return list;

            }
            catch (Exception)
            {

                throw;
            }
          
        }
        public JsonResult AddEmployee(EmployeeModel empObj)
        {
            int a = Insert(empObj);
            return Json(a, JsonRequestBehavior.AllowGet);
        }
        public int Insert(EmployeeModel emp)
        {
            var con = connect();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@Name", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@DepartmentID", emp.DepartmentIDs);
                cmd.Parameters.AddWithValue("@Action", "Insert");
                int i = cmd.ExecuteNonQuery();
                return i;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public JsonResult Delete(int ID)
        {
            return Json(DeleteEmployee(ID), JsonRequestBehavior.AllowGet);
        }

        public int DeleteEmployee(int ID)
        {
            var con = connect();
            try
            {
                SqlCommand cmd = new SqlCommand("EmployeeSP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", ID);
                cmd.Parameters.AddWithValue("@Action", "Delete");
                int i = cmd.ExecuteNonQuery();
                return i;

            }
            catch (Exception)
            {

                throw;
            }
        }
        
    }
}